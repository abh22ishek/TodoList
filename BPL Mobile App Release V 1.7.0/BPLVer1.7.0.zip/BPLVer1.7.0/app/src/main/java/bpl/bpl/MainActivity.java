package bpl.bpl;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.bpl.lifephone.Activitiy.BPLLifePlusActivity;
import com.bpl.lifephone.Model.BPLUserInfo;

public class MainActivity extends Activity {
    Button welcomenext_iv;
    EditText name_welcome_et,age_welcome_et,referenceNumer_welcome_et,refereddoctor_welcome_et,vlename_welcome_et,vlecenterno_welcome_et;
    RadioButton gender_male,gender_female;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);//int flag, int mask
        setContentView(R.layout.activity_main);

        welcomenext_iv=(Button)findViewById(R.id.welcomenext_iv);
        name_welcome_et=(EditText)findViewById(R.id.name_welcome_et);
        age_welcome_et=(EditText)findViewById(R.id.age_welcome_et);
        referenceNumer_welcome_et=(EditText)findViewById(R.id.referenceNumer_welcome_et);
        refereddoctor_welcome_et=(EditText)findViewById(R.id.refereddoctor_welcome_et);
        vlename_welcome_et=(EditText)findViewById(R.id.vlename_welcome_et);
        vlecenterno_welcome_et=(EditText)findViewById(R.id.vlecenterno_welcome_et);

        gender_male=(RadioButton)findViewById(R.id.gender_male);
        gender_female=(RadioButton)findViewById(R.id.gender_female);

        welcomenext_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BPLUserInfo bplUserInfo = new BPLUserInfo();

                try {
                    bplUserInfo.mPatientName = (name_welcome_et.getText().toString());
                    bplUserInfo.mAge = Integer.valueOf(age_welcome_et.getText().toString());
                    bplUserInfo.mRefNumber=(referenceNumer_welcome_et.getText().toString());
                    bplUserInfo.mReferredDoctor=(refereddoctor_welcome_et.getText().toString());
                    bplUserInfo.mVLEName=(vlename_welcome_et.getText().toString());
                    bplUserInfo.mVLECenterNo=(vlename_welcome_et.getText().toString());
                }
                catch (NumberFormatException e){

                }



                if(gender_male.isChecked()){
                    bplUserInfo.mGender = BPLUserInfo.Gender.MALE;
                }else if(gender_female.isChecked()){
                    bplUserInfo.mGender = BPLUserInfo.Gender.FEMALE;
                }

                if(CheckValidation(bplUserInfo))
                {
                    bplUserInfo.mUHID = "0123456789101234";

                    Intent homeIntent = new Intent(getApplicationContext(), BPLLifePlusActivity.class);
                    homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    homeIntent.putExtra("BPLUserInfo", bplUserInfo);
                    startActivity(homeIntent);
                    finish();
                }


            }

            boolean  CheckValidation(BPLUserInfo bplUserInfo){
                boolean result = false;
                if(bplUserInfo.mPatientName.length()!=0){
                    if(bplUserInfo.mAge!=0){
                        if(bplUserInfo.mRefNumber.length()!=0){
                            if(bplUserInfo.mReferredDoctor.length()!=0){
                                if(bplUserInfo.mVLEName.length()!=0){
                                    if(bplUserInfo.mVLECenterNo.length()!=0){
                                        if(gender_male.isChecked() || gender_female.isChecked()){

                                            result = true;
                                        }else {
                                            Toast.makeText(getApplicationContext(),"Please enter Gender",Toast.LENGTH_SHORT).show();
                                        }
                                    }else {
                                        Toast.makeText(getApplicationContext(),"Please enter VLE Center No",Toast.LENGTH_SHORT).show();
                                    }
                                }else {
                                    Toast.makeText(getApplicationContext(),"Please enter VlE Name",Toast.LENGTH_SHORT).show();
                                }
                            }else {
                                Toast.makeText(getApplicationContext(),"Please enter Refered Doctor",Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            Toast.makeText(getApplicationContext(),"Please enter Reference number",Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(getApplicationContext(),"Please enter Age",Toast.LENGTH_SHORT).show();
                    }

                }else {
                    Toast.makeText(getApplicationContext(),"Please enter name",Toast.LENGTH_SHORT).show();
                }

                return result;
            }
        });
    }
}
